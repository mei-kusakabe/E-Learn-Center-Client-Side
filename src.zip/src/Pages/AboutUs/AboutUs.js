import React from 'react';

const AboutUs = () => {
    return (
        <div>
            <h2>about</h2>
        </div>
    );
};

export default AboutUs;